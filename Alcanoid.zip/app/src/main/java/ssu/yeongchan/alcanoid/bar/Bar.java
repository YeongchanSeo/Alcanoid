package ssu.yeongchan.alcanoid.bar;

import java.io.Serializable;

/**
 * Created by Yeongchan on 2017-06-01.
 */

public class Bar implements Serializable{
    private int xPos;
    private int yPos;
    private int standLength;
    private int length;
    private int thickness;

    public Bar(int yPos, int xPos, int length, int thickness){
        this.yPos = yPos;
        this.xPos = xPos;
        this.standLength = length;
        this.length = standLength;
        this.thickness = thickness;
    }

    public int getxPos() {
        return xPos;
    }

    public void setxPos(int xPos) {
        this.xPos = xPos;
    }

    public int getyPos() {
        return yPos;
    }

    public void setyPos(int yPos) {
        this.yPos = yPos;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public int getThickness() {
        return thickness;
    }

    public void setThickness(int thickness) {
        this.thickness = thickness;
    }

    public int getStandLength() {
        return standLength;
    }

    public void setStandLength(int standLength) {
        this.standLength = standLength;
        this.length = standLength;
    }
}
