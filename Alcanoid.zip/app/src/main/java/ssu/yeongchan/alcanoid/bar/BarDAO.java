package ssu.yeongchan.alcanoid.bar;

import java.io.Serializable;

/**
 * Created by Yeongchan on 2017-06-01.
 */

public class BarDAO implements Serializable{
    private Bar bar;
    private int initXPos;
    private int initYPos;

    private int limit;

    public BarDAO(int screenY, int screenX){
        int length = screenX/7;
        int thickness = length/4;
        this.limit = screenX - length;

        this.initYPos = screenY - thickness - 100;
        this.initXPos = screenX/2 - length/2;

        this.bar = new Bar(initYPos, initXPos, length, thickness);
    }

    public void init(){
        this.bar.setxPos(initXPos);
        this.bar.setyPos(initYPos);
    }

    public void move(char key){
        switch (key){
            case 'a': moveLeft(); break;
            case 'd': moveRight(); break;
        }
    }
    public void moveLeft(){
        int xPos = bar.getxPos()-50 > 0 ? bar.getxPos() - 50 : 0;
        bar.setxPos(xPos);
    }

    public void moveRight(){
        int xPos = bar.getxPos()+50 < limit? bar.getxPos() + 50 : limit;
        bar.setxPos(xPos);
    }

    public void modifySetting(float yRate, float xRate, int screenY, int screenX){
        int length = screenX/7;
        int thickness = length/4;

        this.limit = screenX - bar.getLength();

        this.initYPos = screenY - thickness - 100;
        this.initXPos = screenX/2 - length/2;

        bar.setThickness(thickness);
        bar.setStandLength(length);

        bar.setyPos((int)(bar.getyPos()*yRate));
        bar.setxPos((int)(bar.getxPos()*xRate));
    }

    public int getInitXPos() {
        return initXPos;
    }

    public void setInitXPos(int initXPos) {
        this.initXPos = initXPos;
    }

    public int getInitYPos() {
        return initYPos;
    }

    public void setInitYPos(int initYPos) {
        this.initYPos = initYPos;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public Bar getBar() {
        return bar;
    }

    public void setBar(Bar bar) {
        this.bar = bar;
    }
}
