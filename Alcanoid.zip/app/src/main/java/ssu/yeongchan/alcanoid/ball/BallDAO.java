package ssu.yeongchan.alcanoid.ball;

import java.io.Serializable;

import ssu.yeongchan.alcanoid.Alcanoid;
import ssu.yeongchan.alcanoid.bar.Bar;
import ssu.yeongchan.alcanoid.bar.BarDAO;
import ssu.yeongchan.alcanoid.block.Block;
import ssu.yeongchan.alcanoid.block.BlockDAO;
import ssu.yeongchan.battlealcanoid.MainActivity;

/**
 * Created by Yeongchan on 2017-06-02.
 */

public class BallDAO implements Serializable {
    private Ball ball;

    private int initXPos;
    private int initYPos;
    private int yMove;
    private int xMove;

    private int passItem;

    public BallDAO(BarDAO barDAO) {
        int radius = barDAO.getBar().getThickness()/3;

        this.initYPos = barDAO.getInitYPos() - radius - 1;
        this.initXPos = barDAO.getInitXPos() + barDAO.getBar().getLength()/2;

        this.yMove = 1;
        this.xMove = 1;

        this.passItem = 0;



        this.ball = new Ball(initYPos, initXPos, radius);
    }

    public void init(){
        ball.setxPos(initXPos);
        ball.setyPos(initYPos);
        xMove = 1;
        yMove = 1;
    }

    public void modifySetting(float yRate, float xRate, BarDAO barDAO){
        int radius = barDAO.getBar().getThickness()/3;

        this.initYPos = barDAO.getInitYPos() - radius - 1;
        this.initXPos = barDAO.getInitXPos() + barDAO.getBar().getLength()/2;

        ball.setStandRadius(radius);

        ball.setyPos((int)(ball.getyPos()*yRate));
        ball.setxPos((int)(ball.getxPos()*xRate));
    }

    public boolean move(final BlockDAO blockDAO, BarDAO barDAO, int screenY, int screenX){
        int blockWidth = blockDAO.search(0,0).getWidth();
        int blockHeight = blockDAO.search(0,0).getHeight();

        int xPos = ball.getxPos();
        int yPos = ball.getyPos();
        int radius = ball.getRadius();
        int blockXPos, blockYPos;

        boolean xCrash = false;
        boolean yCrash = false;

        boolean isWall = false;

        for (int y = 0; y < blockDAO.getColumns(); y++) {
            for (int x = 0; x < blockDAO.getRows(); x++) {
                blockXPos = blockDAO.search(y,x).getxPos();
                blockYPos = blockDAO.search(y,x).getyPos();

                if(blockDAO.search(y,x).getColor() != -1)
                    if(blockXPos - radius  <= xPos && blockXPos + blockWidth + radius >= xPos
                            && blockYPos - radius <= yPos && blockYPos + + blockHeight + radius >= yPos ) {

                        switch(passItem){
                            case 0:
                                if(blockYPos - radius >= yPos || blockYPos + blockHeight + radius <= yPos)
                                    yCrash = true;
                                if(blockXPos -radius >= xPos || blockXPos + blockWidth + radius <= xPos)
                                    xCrash = true;
                            case 1:
                                if(blockDAO.search(y, x).getColor() != 0) {
                                    blockDAO.crush(y, x, barDAO.getBar(), this);
                                }
                                else
                                    blockDAO.search(y, x).setColor(7);
                        }

                    }
                }
        }

        if(yPos - radius <= 0) {
            yCrash = true;
        }
        if(xPos - radius <= 0 || xPos + radius >= screenX) {
            xCrash = true;
        }

        int barXPos = barDAO.getBar().getxPos();
        int barYPos = barDAO.getBar().getyPos();
        int length = barDAO.getBar().getLength();
        int thickness = barDAO.getBar().getThickness();

        if(barXPos - radius <= xPos && barXPos + length + radius >= xPos
            && barYPos - radius <= yPos && barYPos + thickness + radius >= yPos) {
            if (barXPos - radius >= xPos || barXPos + length + radius <= xPos)
                xCrash = true;
            if(barYPos - radius >= yPos || barYPos + thickness + radius <= yPos)
                yCrash = true;
        }

        if (xCrash)
            xMove = -xMove;
        if (yCrash)
            yMove = -yMove;


        ball.setxPos(ball.getxPos() - xMove);
        ball.setyPos(ball.getyPos() - yMove);

        if(yPos- radius >= screenY) {
            barDAO.getBar().setLength(barDAO.getBar().getStandLength());
            passItem = 0;
            return false;
        }

        return true;
    }

    public Ball getBall() {
        return ball;
    }

    public void setBall(Ball ball) {
        this.ball = ball;
    }

    public int getInitXPos() {
        return initXPos;
    }

    public void setInitXPos(int initXPos) {
        this.initXPos = initXPos;
    }

    public int getInitYPos() {
        return initYPos;
    }

    public void setInitYPos(int initYPos) {
        this.initYPos = initYPos;
    }

    public int getyMove() {
        return yMove;
    }

    public void setyMove(int yMove) {
        this.yMove = yMove;
    }

    public int getxMove() {
        return xMove;
    }

    public void setxMove(int xMove) {
        this.xMove = xMove;
    }

    public int getPassItem() {
        return passItem;
    }

    public void setPassItem(int passItem) {
        this.passItem = passItem;
    }
}
