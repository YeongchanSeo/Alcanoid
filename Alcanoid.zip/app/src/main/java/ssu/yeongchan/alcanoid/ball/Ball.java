package ssu.yeongchan.alcanoid.ball;

import java.io.Serializable;

/**
 * Created by Yeongchan on 2017-06-02.
 */

public class Ball implements Serializable{

    private int xPos;
    private int yPos;
    private int standRadius;
    private int radius;

    public Ball(int yPos, int xPos, int radius){
        this.yPos = yPos;
        this.xPos = xPos;
        this.standRadius = radius;
        this.radius = standRadius;
    }

    public int getxPos() {
        return xPos;
    }

    public void setxPos(int xPos) {
        this.xPos = xPos;
    }

    public int getyPos() {
        return yPos;
    }

    public void setyPos(int yPos) {
        this.yPos = yPos;
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    public int getStandRadius() {
        return standRadius;
    }

    public void setStandRadius(int standRadius) {
        this.standRadius = standRadius;
        this.radius = standRadius;
    }
}
