package ssu.yeongchan.alcanoid.block;

/**
 * Created by Yeongchan on 2017-05-31.
 */

import android.util.Log;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

import ssu.yeongchan.alcanoid.Alcanoid;
import ssu.yeongchan.alcanoid.ball.BallDAO;
import ssu.yeongchan.alcanoid.bar.Bar;

public class BlockDAO implements Serializable{
    private List<Block> blockList;
    private int rows;
    private int columns;

    public BlockDAO(int screenX, int columns, int rows){
        this.blockList = new LinkedList<Block>();

        this.columns = columns;
        this.rows = rows;

        int width = (screenX - 20 - ((rows - 1) * 5)) / rows;
        int height = width/3;

        Block.setWidth(width);
        Block.setHeight(height);

        for(int y=0; y<columns; y++)
            for(int x=0; x<rows; x++){
                Block block = new Block();
                block.setColor(y%7);
                int item = new Random().nextInt()%14;
                item = item - 7 > 0 ? item - 7 : 0;
                block.setItem(item);
                blockList.add(block);
            }
    }

    public BlockDAO(BlockDAO dao){
        this.blockList = new LinkedList<Block>();
        for(int i=0; i<dao.getBlockList().size(); i++)
            this.blockList.add(dao.blockList.get(i)) ;
        this.columns = dao.getColumns();
        this.rows= dao.getRows();
    }

    public void modifySetting(int screenX){

        int width = (screenX - 20 - ((rows - 1) * 5)) / rows;
        int height = width/3;

        for(int y=0; y<columns; y++)
            for(int x=0; x<rows; x++){
                blockList.get(y*rows + x).setWidth(width);
                blockList.get(y*rows + x).setHeight(height);
            }
    }

    public Block search(int column, int row) {return blockList.get(column*rows + row);}

    public void crush(int column, int row, Bar bar, BallDAO ballDAO){
        search(column, row).setColor(-1);
        new Item(column, row, bar, ballDAO).start();
    }

    public boolean crushAll() {
        boolean running = false;
        for (int y = 0; y < columns; y++)
            for (int x = 0; x < rows; x++) {
                if(search(y,x).getColor() != -1){
                    running = true;
                }
            }
        if(running)
            return false;

        return true;
    }

    class Item extends Thread implements Serializable{
        private Block block;
        private Bar bar;
        private BallDAO ballDAO;
        private ItemAction itemAction;
        private boolean dropping = true;

        public Item(int y, int x, Bar bar, BallDAO ballDAO){
            this.block = search(y, x);
            this.bar = bar;
            this.ballDAO = ballDAO;
            itemAction = new ItemAction(new OnItem(block.getItem()), new OffItem(block.getItem()));
        }
        public void run() {
            final int item = block.getItem();
            while(dropping) {
                if(block.getxPos() + block.getWidth() >= bar.getxPos() && block.getxPos() <= bar.getxPos() + bar.getLength()
                        && block.getyPos() + block.getHeight() >= bar.getyPos() && block.getyPos() <= bar.getyPos() + bar.getThickness()) {
                    dropping = false;

                    try {
                        itemAction.run(block.getItem());
                    } catch (Exception e){
                        e.printStackTrace();
                    }

                    return;
                }

                block.setyPos(block.getyPos() + 1);

                try{
                    sleep(10);
                } catch (Exception e){
                    e.printStackTrace();
                }

            }
        }

        class ItemAction implements Serializable{
            private ItemHandler hDo, hUndo;
            public ItemAction(ItemHandler d, ItemHandler u) {
                hDo = d;	hUndo = u;
            }

            public void run(int itemNumber) throws Exception{
                hDo.run(itemNumber);
                block.setItem(0);
                sleep(10000);
                hUndo.run(itemNumber);
            }
        }
        public class OnItem implements ItemHandler, Serializable {
            private int itemNumber;

            public OnItem(int itemNumber){
                this.itemNumber = itemNumber;
            }
            public void run(int itemNumber) {
                switch (itemNumber){
                    case 1: bar.setLength(bar.getStandLength()*2); break;
                    case 2: bar.setLength(bar.getStandLength()/2); break;
                    case 3: ballDAO.setPassItem(1);  break;
                    case 4: ++Alcanoid.life; break;
                    case 5: ballDAO.getBall().setRadius(ballDAO.getBall().getStandRadius()*2); break;
                    case 6: break;
                }
            }
        }

        public class OffItem implements ItemHandler, Serializable {
            private int itemNumber;

            public OffItem(int itemNumber){
                this.itemNumber = itemNumber;
            }
            public void run(int itemNumber) {
                switch (itemNumber){
                    case 1:
                    case 2: bar.setLength(bar.getStandLength()); break;
                    case 3: ballDAO.setPassItem(0); break;
                    case 4: break;
                    case 5: ballDAO.getBall().setRadius(ballDAO.getBall().getStandRadius()); break;
                    case 6: break;
                }
            }
        }
    }
    interface ItemHandler{
        public void run(int key);
    }
    public List<Block> getBlockList() {
        return blockList;
    }

    public void setBlockList(List<Block> blockList) {
        this.blockList = blockList;
    }

    public int getRows() {
        return rows;
    }

    public void setRows(int rows) {
        this.rows = rows;
    }

    public int getColumns() {
        return columns;
    }

    public void setColumns(int columns) {
        this.columns = columns;
    }
}
