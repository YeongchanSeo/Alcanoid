package ssu.yeongchan.alcanoid.block;

import java.io.Serializable;

/**
 * Created by Yeongchan on 2017-05-31.
 */

public class Block implements Serializable {
    private int color;
    private int item;
    private int xPos;
    private int yPos;
    private static int width;
    private static int height;

    public int getItem() {
        return item;
    }

    public void setItem(int item) {
        this.item = item;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public int getxPos() {
        return xPos;
    }

    public void setxPos(int xPos) {
        this.xPos = xPos;
    }

    public int getyPos() {
        return yPos;
    }

    public void setyPos(int yPos) {
        this.yPos = yPos;
    }

    public static int getWidth() {
        return width;
    }

    public static void setWidth(int mWidth) {
        width = mWidth;
    }

    public static int getHeight() {
        return height;
    }

    public static void setHeight(int mHeight) {
        height = mHeight;
    }
}
