package ssu.yeongchan.alcanoid;

import java.io.Serializable;

import ssu.yeongchan.alcanoid.ball.BallDAO;
import ssu.yeongchan.alcanoid.bar.BarDAO;
import ssu.yeongchan.alcanoid.block.Block;
import ssu.yeongchan.alcanoid.block.BlockDAO;

/**
 * Created by Yeongchan on 2017-05-27.
 */

public class Alcanoid implements Serializable{
    private BlockDAO blockDAO;
    private BarDAO barDAO;
    private BallDAO ballDAO;

    public int left;
    public static int life;

    private int screenX;
    private int screenY;

    private AlcanoidState state;

    private OnLeft myOnLeft = new OnLeft();
    private OnRight myOnRight = new OnRight();
    public void setOnLeftListener(OnLeft listener) { alcanoidActionsInitialized = false; myOnLeft = listener; }
    public void setOnRightListener(OnRight listener) { alcanoidActionsInitialized = false; myOnRight = listener; }

    protected void moveLeft(char key, boolean update) throws Exception { moveLeft.run(this, key, update); }
    protected void moveRight(char key, boolean update) throws Exception { moveRight.run(this, key, update); }

    protected AlcanoidAction moveLeft, moveRight;

    protected boolean alcanoidActionsInitialized = false;

    public Alcanoid(int columns, int rows, int screenY, int screenX) throws Exception {
        this.screenX = screenX;
        this.screenY = screenY;

        this.blockDAO = new BlockDAO(screenX, columns, rows);
        this.barDAO = new BarDAO(screenY, screenX);
        this.ballDAO = new BallDAO(barDAO);

        this.life = 3;
    }

    public AlcanoidState accept(char key) throws Exception {
        if (alcanoidActionsInitialized == false)
            setAlcanoidActions();
        if (life < 0 ) {
            state = AlcanoidState.Finished;

            return state;
        } else if(blockDAO.crushAll()){
            state = AlcanoidState.Win;

            return state;
        }

        switch(key) {
            case 'a': moveLeft(key, true); break; // move left
            case 'd': moveRight(key, true); break; // move right
            case 's': moveBall(); break;
            default: System.out.println("unknown key!");
        }
        return state;
    }

    public void moveBall(){
        if(!ballDAO.move(blockDAO, barDAO, screenY, screenX)) {
            --life;
            barDAO.init();
            ballDAO.init();
        }
    }

    public void rotateScreen(float yRate, float xRate, int screenY, int screenX){
        this.screenY = screenY;
        this.screenX = screenX;

        blockDAO.modifySetting(screenX);
        barDAO.modifySetting(yRate, xRate, screenY, screenX);
        ballDAO.modifySetting(yRate, xRate, barDAO);
    }

    public enum AlcanoidState {
        Running(0), Finished(1), Win(2);
        private final int value;
        private AlcanoidState(int value) { this.value = value; }
        public int value() { return value; }
    }


    protected void setAlcanoidActions() {
        moveLeft  = new AlcanoidAction(myOnLeft);
        moveRight = new AlcanoidAction(myOnRight);
        alcanoidActionsInitialized = true;
        System.out.println("Alcanoid:setAlcanoidActions() called");
    }

    class AlcanoidAction implements Serializable{
        private ActionHandler hDo;
        public AlcanoidAction(ActionHandler d) {
            hDo = d;
        }

        public void run(Alcanoid a, char key, boolean update) throws Exception {
            hDo.run(a, key);
            barDAO.move(key);
        }
    }
    public interface ActionHandler {
        public void run(Alcanoid a, char key) throws Exception;
    }
    public class OnLeft implements ActionHandler, Serializable {
        public void run(Alcanoid a, char key) { a.left = a.left - 1; }
    }
    public class OnRight implements ActionHandler, Serializable {
        public void run(Alcanoid a, char key) { a.left = a.left + 1; }
    }

    public BlockDAO getBlockDAO() {
        return blockDAO;
    }

    public void setBlockDAO(BlockDAO blockDAO) {
        this.blockDAO = blockDAO;
    }

    public BarDAO getBarDAO() {
        return barDAO;
    }

    public void setBarDAO(BarDAO barDAO) {
        this.barDAO = barDAO;
    }

    public BallDAO getBallDAO() {
        return ballDAO;
    }

    public void setBallDAO(BallDAO ballDAO) {
        this.ballDAO = ballDAO;
    }
}