package ssu.yeongchan.battlealcanoid;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

import java.io.Serializable;

import ssu.yeongchan.alcanoid.Alcanoid;
import ssu.yeongchan.alcanoid.ball.Ball;
import ssu.yeongchan.alcanoid.bar.Bar;
import ssu.yeongchan.alcanoid.block.Block;
import ssu.yeongchan.alcanoid.block.BlockDAO;

/**
 * Created by Yeongchan on 2017-06-01.
 */

public class AlcanoidView extends View implements Serializable{
    private int columns, rows;
    private int blockWidth, blockHeight;
    private int length, thickness;
    private int radius;
    private int color = Color.BLACK;

    private Paint paint = new Paint();
    private Alcanoid alcanoid = null;
    private BlockDAO blocks;
    private Bar bar;
    private Ball ball;

    public AlcanoidView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }

    public AlcanoidView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public AlcanoidView(Context context) {
        super(context);
    }

    public void init(int columns, int rows) {
        this.columns = columns;
        this.rows = rows;
    }

    public void accept(Alcanoid a) {
        alcanoid = a;

        blocks= a.getBlockDAO();
        bar = a.getBarDAO().getBar();
        ball = a.getBallDAO().getBall();

        blockWidth = Block.getWidth();
        blockHeight = Block.getHeight();

        length = bar.getLength();
        thickness = bar.getThickness();

        radius = ball.getRadius();
    }

    public void onDraw(Canvas canvas) {
        if (alcanoid == null) return;

        super.onDraw(canvas);
        paint.setStyle(Paint.Style.FILL);

        int yPos = 50;
        int xPos = 10;

        for (int y = 0; y < columns; y++) {
            for (int x = 0; x < rows; x++) {
                switch (blocks.search(y,x).getColor() ){
                    case -1:
                        paint.setColor(Color.BLACK);
                        break;
                    case 0:
                        paint.setColor(Color.GRAY);
                        break;
                    case 1:
                        paint.setColor(Color.RED);
                        break;
                    case 2:
                        paint.setColor(Color.YELLOW);
                        break;
                    case 3:
                        paint.setColor(Color.BLUE);
                        break;
                    case 4:
                        paint.setColor(Color.MAGENTA);
                        break;
                    case 5:
                        paint.setColor(Color.CYAN);
                        break;
                    case 6:
                        paint.setColor(Color.GREEN);
                        break;
                    case 7:
                        paint.setColor(Color.LTGRAY);
                    default:
                        paint.setColor(Color.WHITE);
                        break;
                }
                if (blocks.search(y,x).getColor() == -1) {
                    switch (blocks.search(y, x).getItem()) {
                        case 0:
                            break;
                        case 1:
                            paint.setColor(Color.rgb(255,100,0));
                            break;
                        case 2:
                            paint.setColor(Color.rgb(100,255,0));
                            break;
                        case 3:
                            paint.setColor(Color.rgb(100,0,255));
                            break;
                        case 4:
                            paint.setColor(Color.rgb(255,0,100));
                            break;
                        case 5:
                            paint.setColor(Color.rgb(0,100,255));
                            break;
                        case 6:
                            paint.setColor(Color.rgb(0,255,100));
                            break;
                    }
                    if(blocks.search(y,x).getItem() != 0)
                    canvas.drawRect(xPos, blocks.search(y, x).getyPos(), xPos + blockWidth, blocks.search(y, x).getyPos() + blockHeight, paint);
                }
                else {
                    blocks.search(y,x).setxPos(xPos);
                    blocks.search(y,x).setyPos(yPos);
                    canvas.drawRect(xPos, yPos, xPos + blockWidth, yPos + blockHeight, paint);
                }
                xPos += (blockWidth + 5);
            }
            xPos = 10;
            yPos += (blockHeight + 5);
        }

        xPos = bar.getxPos();
        yPos = bar.getyPos();

        paint.setColor(Color.GRAY);
        canvas.drawRect(xPos, yPos, xPos + length, yPos + thickness, paint);

        xPos = ball.getxPos();
        yPos = ball.getyPos() ;

        paint.setColor(Color.WHITE);
        canvas.drawOval(new RectF(xPos - radius, yPos - radius, xPos + radius, yPos + radius), paint);

        paint.setColor(Color.GRAY);

        xPos = 10;
        yPos = getHeight() - thickness - 10;

        int lifeBarLength = bar.getStandLength()/2;

        for(int i=0; i< alcanoid.life; i++){
            canvas.drawRect(xPos, yPos, xPos + lifeBarLength, yPos + thickness/2, paint);
            xPos += lifeBarLength + 10;
        }
    }
}
