package ssu.yeongchan.battlealcanoid;

import java.io.Serializable;

import ssu.yeongchan.alcanoid.Alcanoid;

/**
 * Created by Yeongchan on 2017-05-31.
 */

public class AlcanoidModel implements Serializable{
    public Alcanoid board;
    public AlcanoidModel(int colums, int rows, int screenY, int screenX) throws Exception{
        board = new Alcanoid(colums, rows, screenY, screenX);
    }

    public Alcanoid.AlcanoidState accept(char ch) throws Exception {
        return board.accept(ch);
    }
}
