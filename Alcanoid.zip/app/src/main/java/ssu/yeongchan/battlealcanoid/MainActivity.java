package ssu.yeongchan.battlealcanoid;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Surface;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Toast;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import ssu.yeongchan.alcanoid.Alcanoid;
import ssu.yeongchan.alcanoid.R;

public class MainActivity extends AppCompatActivity {

    private AlcanoidView myAlcanoidView, peerAlcanoidView;
    private AlcanoidModel myAlcanoidModel, peerAlcanoidModel;
    private Button startBtn, quitBtn;
    private Button leftArrowBtn, rightArrowBtn;
    private int columns = 6, rows = 8;
    private char savedKey;
    private GameState savedState;
    private int savedScreenY, savedScreenX;
    private GameState gameState = GameState.Initial;
    private GameState peerGameState = GameState.Initial;

    private Timer timer;
    private AlertDialog quit;
    private  String gameResult = "You Win!";
    private int mode;

    private final int reqCode4SettingActivity = 0;
    private String serverHostName = "10.0.2.2";
    private int serverPortNum = 9000;
    private String myNickName = "me";
    private String peerNickName = "you";
    private ChatServer chatServer;
    boolean connected = false, rotate = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowManager wm = getWindowManager();
        if (wm == null) return;

        Intent data = getIntent();
        this.mode = getIntent().getExtras().getInt("mode");
        int rotation = wm.getDefaultDisplay().getRotation();

        switch (mode){
            case 1:
                if(rotation == Surface.ROTATION_0 || rotation == Surface.ROTATION_180) {
                    Log.d("MainActivity", "onCreate: portrait mode");
                    setContentView(R.layout.activity_main);
                } else {
                    Log.d("MainActivity", "onCreate: landscape mode");
                    setContentView(R.layout.activity_main_landscape);
                }
                break;
            case 2:
                if(chatServer == null){
                    serverHostName = data.getStringExtra("serverHostName");
                    String s = data.getStringExtra("serverPortNum");
                    serverPortNum = Integer.parseInt(s);
                    myNickName = data.getStringExtra("myNickName");
                    peerNickName = data.getStringExtra("peerNickName");
                    Log.d("MainActivity", "SettingActivity returned ("+serverHostName+","+serverPortNum+","+myNickName+","+peerNickName+")");
                    connected = true;
                }
                if(rotation == Surface.ROTATION_0 || rotation == Surface.ROTATION_180) {
                    Log.d("MainActivity", "onCreate: portrait mode");
                    setContentView(R.layout.activity_main2);
                } else {
                    Log.d("MainActivity", "onCreate: landscape mode");
                    setContentView(R.layout.activity_main_landscape2);
                }
                break;
        }


        myAlcanoidView = (AlcanoidView) findViewById(R.id.myAlcanoidView);
        peerAlcanoidView = (AlcanoidView) findViewById(R.id.peerAlcanoidView);
        startBtn = (Button) findViewById(R.id.startBtn);
        quitBtn = (Button) findViewById(R.id.quitBtn);
        quit = (AlertDialog) AlertDialogBtnCreate();
        leftArrowBtn = (Button) findViewById(R.id.leftArrowBtn);
        rightArrowBtn = (Button) findViewById(R.id.rightArrowBtn);

        startBtn.setOnClickListener(OnClickListener);
        quitBtn.setOnClickListener(OnClickListener);
        leftArrowBtn.setOnClickListener(OnClickListener);
        rightArrowBtn.setOnClickListener(OnClickListener);

        setButtonsState();
        if(chatServer == null)
            chatServer = new ChatServer(hPeerViews, MainActivity.this);
    }

    protected void onPause() {
        super.onPause();
        savedState = gameState;
        if (gameState == GameState.Running)
            executeUserCommand(UserCommand.Pause);
    }

    protected void onResume() {
        super.onResume();
        if (savedState == GameState.Running)
            executeUserCommand(UserCommand.Resume);
    }

    protected void onDestroy() {
        super.onDestroy();
        Log.d("MainActivity", "onDestroy");
        if (mode == 2 && chatServer.isAvailable() && !connected) {
            chatServer.send('Q');
            chatServer.disconnect();
        }
    }

    private class TimerHandler extends TimerTask{
        public void run() {
            if (chatServer.isAcknowledged() == false) return;
            savedKey = 's';
            executeUserCommand(UserCommand.Update);
        }
    }

    public void enableTimer() {
        if (timer == null) {
            TimerHandler job = new TimerHandler();
            timer = new Timer(true);
            timer.schedule(job, 0, 3);
        }
    }

    private void disableTimer() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    private AlertDialog AlertDialogBtnCreate() {
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Alcanoid: ")
                .setMessage("Do you want to quit?")
                .setCancelable(false)
                .setPositiveButton("yes", new DialogInterface.OnClickListener(){

                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        gameResult = "You Lose!";
                        executeUserCommand(UserCommand.Quit);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        if (savedState == GameState.Running)
                            executeUserCommand(UserCommand.Resume);
                    }
                });

        return builder.create();
    }

    private Handler hMyViews = new Handler();
    private Handler hPeerViews = new Handler() {
        public void handleMessage(Message msg) {
            if (chatServer.isAvailable() == false) return;
            char key = chatServer.getchar(msg);
            Alcanoid.AlcanoidState state = Alcanoid.AlcanoidState.Finished;
            if (key == 'Q') { // peer has terminated the game.
                gameResult = "You Win!";
                executeUserCommand(UserCommand.Win);
                return;
            }
            if (peerGameState == GameState.Initial) {
                try { peerAlcanoidModel =
                        new AlcanoidModel(columns, rows, peerAlcanoidView.getHeight(), peerAlcanoidView.getWidth()); }
                catch (Exception e) { e.printStackTrace(); }
                peerAlcanoidView.init(columns, rows);
                peerAlcanoidView.accept(peerAlcanoidModel.board);
                peerAlcanoidView.invalidate();

                peerGameState = GameState.Running;
            }
            else {
                try {
                    state = peerAlcanoidModel.accept(key);
                }
                catch (Exception e) { e.printStackTrace(); }
                peerAlcanoidView.accept(peerAlcanoidModel.board);
                peerAlcanoidView.invalidate();

                if (state == Alcanoid.AlcanoidState.Finished)
                    executeUserCommand(UserCommand.Win);
            }
            return;
        };
    };

    int stateMatrix[][] = {
            {-1, 1, -1, -1, -1, 2, 0},
            {0, -1, 2, -1, 1, -1, 0},
            {0, 1, -1, 1, 2, -1, -1}
    };

    private void executeUserCommand(UserCommand cmd) {
        GameState prevState = gameState;

        gameState = GameState.fromInteger(stateMatrix[gameState.value()][cmd.value()]);
        if (gameState == GameState.Error) {
            Log.d("MainActivity", "game state error! (state.cmd)=(" + prevState.value() + "," + cmd.value() + ")");
            gameState = prevState;
            return;
        }
        switch (cmd.value()) {
            case 0 : disableTimer(); hMyViews.post(runnableQuit); break;
            case 1: enableTimer(); hMyViews.post(runnableStart); break;
            case 2: disableTimer(); hMyViews.post(runnablePause); break;
            case 3: enableTimer(); hMyViews.post(runnableResume); break;
            case 4: hMyViews.post(runnableUpdate); break;
            case 5: hMyViews.post(runnableRecover); break;
            case 6: disableTimer(); hMyViews.post(runnableWin); break;
            default: Log.d("MainActivity", "unknown user command!"); break;
        }
    }

    private Runnable runnableStart = new Runnable() {
        public void run() {
            try {

                myAlcanoidModel = new AlcanoidModel(columns, rows, myAlcanoidView.getHeight(), myAlcanoidView.getWidth());

                myAlcanoidView.init(columns, rows);
                myAlcanoidView.accept(myAlcanoidModel.board);
                myAlcanoidView.invalidate();

                if (mode == 2) {
                    if (chatServer.connect(serverHostName, serverPortNum, myNickName, peerNickName) == false ) {
                        gameResult = "Connection Error!";
                        executeUserCommand(UserCommand.Quit);
                        return;
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            setButtonsState();
            startBtn.setText("Pause");
            Toast.makeText(MainActivity.this, "Game Started!", Toast.LENGTH_SHORT).show();
        }
    };

    boolean buttonState[][] = {
            {true, false},
            {true, true},
            {true, false}
    };

    private Runnable runnablePause = new Runnable() {
        public void run() {
            setButtonsState();
            startBtn.setText("Resume");
            Toast.makeText(MainActivity.this, "Game Paused!", Toast.LENGTH_SHORT).show();
        }
    };

    private Runnable runnableResume = new Runnable() {
        public void run() {
            setButtonsState();
            startBtn.setText("Pause");
            Toast.makeText(MainActivity.this, "Game Resumed!", Toast.LENGTH_SHORT).show();
        }
    };

    private Runnable runnableRecover = new Runnable() {
        public void run() {

            myAlcanoidView.init(columns, rows);
            myAlcanoidView.accept(myAlcanoidModel.board);
            myAlcanoidView.invalidate();
            myAlcanoidModel.board.rotateScreen((float) myAlcanoidView.getHeight() / savedScreenY,
                    (float) myAlcanoidView.getWidth() / savedScreenX, myAlcanoidView.getHeight(), myAlcanoidView.getWidth());
            if (mode == 2) {
                peerAlcanoidView.init(columns, rows);
                peerAlcanoidView.accept(peerAlcanoidModel.board);
                peerAlcanoidView.invalidate();
                peerAlcanoidModel.board.rotateScreen((float) peerAlcanoidView.getHeight() / savedScreenY,
                        (float) peerAlcanoidView.getWidth() / savedScreenX, peerAlcanoidView.getHeight(), peerAlcanoidView.getWidth());
            }

            setButtonsState();


            Toast.makeText(MainActivity.this, "Game Recovered!", Toast.LENGTH_SHORT).show();
            if (savedState == GameState.Running) {
                hMyViews.post(runnableResume);
                //hPeerViews.post(runnableResume);
            } else if (savedState == GameState.Paused){
                startBtn.setText("Resume");
            }
        }
    };

    private Runnable runnableQuit = new Runnable() {
        public void run() {
            setButtonsState();
            startBtn.setText("Start");

            Toast.makeText(MainActivity.this, gameResult, Toast.LENGTH_SHORT).show();

            if (mode == 2 && chatServer.isAvailable()) {
                chatServer.send('Q');
                chatServer.disconnect();
                peerGameState = GameState.Initial;
            }
        }
    };

    private void setButtonsState() {
        boolean startFlag = buttonState[gameState.value()][0];
        boolean otherFlag = buttonState[gameState.value()][1];

        startBtn.setEnabled(startFlag);
        leftArrowBtn.setEnabled(otherFlag);
        rightArrowBtn.setEnabled(otherFlag);
    }

    private Runnable runnableUpdate = new Runnable() {
        Alcanoid.AlcanoidState state;
        public void run() {
            try {
                if(savedKey == 'N')
                    return;
                state = myAlcanoidModel.accept(savedKey);
                if (mode == 2) {
                    if (!chatServer.send(savedKey)) {
                        gameResult = "Connection Error!";
                        executeUserCommand(UserCommand.Quit);
                        return;
                    }
                }
                myAlcanoidView.accept(myAlcanoidModel.board);
                myAlcanoidView.invalidate();

                if (state == Alcanoid.AlcanoidState.Finished) {
                    gameResult = "You Lose!";
                    executeUserCommand(UserCommand.Quit);
                } else if(state == Alcanoid.AlcanoidState.Win) {
                    gameResult = "You Win!";
                    executeUserCommand(UserCommand.Win);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    private Runnable runnableWin = new Runnable() {
        public void run() {
            setButtonsState();
            startBtn.setText("Start");
            Toast.makeText(MainActivity.this, gameResult, Toast.LENGTH_SHORT).show();

            if (mode == 2 && chatServer.isAvailable()) {
                chatServer.disconnect();
                peerGameState = GameState.Initial; // try not to init peerGameState before the server is disconnected.
            }
        }
    };

    private View.OnClickListener OnClickListener = new View.OnClickListener() {
        public void onClick(View v) {
            char key;
            int id = v.getId();
            UserCommand cmd = UserCommand.NOP;
            switch (id) {
                case R.id.startBtn:
                    savedKey = 'N';
                    if (gameState == GameState.Initial) cmd = UserCommand.Start;
                    else if (gameState == GameState.Running) cmd = UserCommand.Pause;
                    else if (gameState == GameState.Paused) cmd = UserCommand.Resume;
                    savedState = gameState;
                    break;
                case R.id.quitBtn:
                    if (gameState == GameState.Initial) {
                        finish();
                        return;
                    }
                    else if (gameState == GameState.Running) {
                        savedState = gameState;
                        executeUserCommand(UserCommand.Pause);
                        quit.show();
                        return;
                    }
                    else if (gameState == GameState.Paused) {
                    savedState = gameState;
                    quit.show();
                    return;
                    }
                    break;
                case R.id.leftArrowBtn:
                    savedKey = 'a';
                    cmd = UserCommand.Update;
                    break;
                case R.id.rightArrowBtn:
                    savedKey = 'd';
                    cmd = UserCommand.Update;
                    break;
                default:
                    return;
            }
            executeUserCommand(cmd);
        }
    };

    public enum UserCommand {
        NOP(-1), Quit(0), Start(1), Pause(2), Resume(3), Update(4), Recover(5), Win(6);
        private final int value;

        private UserCommand(int value) {
            this.value = value;
        }

        public int value() {
            return value;
        }
    }

    public enum GameState {
        Error(-1), Initial(0), Running(1), Paused(2);
        private final int value;

        private GameState(int value) {
            this.value = value;
        }

        public int value() {
            return value;
        }

        public static GameState fromInteger(int value) {
            switch (value) {
                case -1:
                    return Error;
                case 0:
                    return Initial;
                case 1:
                    return Running;
                case 2:
                    return Paused;
                default:
                    return null;
            }
        }
    }

    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d("MainActivity", "onSave");
        outState.putSerializable("myAlcanoidModel", myAlcanoidModel);
        outState.putInt("savedState", savedState.value());
        outState.putInt("savedScreenY", myAlcanoidView.getHeight());
        outState.putInt("savedScreenX", myAlcanoidView.getWidth());
        if (mode == 2) {
            outState.putSerializable("chatServer", chatServer);
            outState.putInt("mode", mode);
            outState.putSerializable("peerAlcanoidModel", peerAlcanoidModel);
            outState.putSerializable("peerAlcanoidView", peerAlcanoidView);
            outState.putInt("peerGameState", peerGameState.value());
        }
    }

    protected void onRestoreInstanceState(Bundle inState) {
        super.onRestoreInstanceState(inState);
        Log.d("MainActivity", "onRestore");

        savedState = GameState.fromInteger(inState.getInt("savedState"));
        savedScreenY = inState.getInt("savedScreenY");
        savedScreenX = inState.getInt("savedScreenX");
        mode = inState.getInt("mode");

        if (savedState != GameState.Initial) {
            myAlcanoidModel = (AlcanoidModel) inState.getSerializable("myAlcanoidModel");
            executeUserCommand(UserCommand.Recover);
            if(mode == 2){
                chatServer = (ChatServer) inState.getSerializable("chatServer");
                peerAlcanoidModel = (AlcanoidModel) inState.getSerializable("peerAlcanoidModel");
                peerGameState = GameState.fromInteger(inState.getInt("peerGameState"));
            }
        }
    }
}
