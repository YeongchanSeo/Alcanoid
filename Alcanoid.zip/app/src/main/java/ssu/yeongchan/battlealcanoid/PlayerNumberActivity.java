package ssu.yeongchan.battlealcanoid;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import ssu.yeongchan.alcanoid.R;

/**
 * Created by Yeongchan on 2017-06-05.
 */

public class PlayerNumberActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choice);
    }

    public void onClick(View view){
        Intent intent;
        int mode = 0;
        switch(view.getId()){
            case R.id.playOne:
                mode = 1;
                intent=new Intent(PlayerNumberActivity.this, MainActivity.class);
                break;
            case R.id.playTwo:
                mode = 2;
                intent=new Intent(PlayerNumberActivity.this, SettingActivity.class);
                break;
            default: intent=new Intent(PlayerNumberActivity.this, MainActivity.class);
        }

        intent.putExtra("mode", mode);
        startActivity(intent);

    }
}
